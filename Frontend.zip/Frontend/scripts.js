// Simulated occupancy data
const courtData = {
    "court-1": { occupancy: 3, maxCapacity: 10 },
    "court-2": { occupancy: 8, maxCapacity: 10 },
};

// Function to update court data
function updateCourtData() {
    Object.keys(courtData).forEach((courtId) => {
        const court = courtData[courtId];
        const countElement = document.getElementById(`${courtId}-count`);
        const statusElement = document.getElementById(`${courtId}-status`);

        // Update occupancy count
        countElement.innerText = `${court.occupancy} / ${court.maxCapacity}`;

        // Update status
        if (court.occupancy < court.maxCapacity) {
            statusElement.innerText = "Available";
            statusElement.style.color = "green";
        } else {
            statusElement.innerText = "Full";
            statusElement.style.color = "red";
        }
    });
}

// Simulate real-time data update every 3 seconds
setInterval(updateCourtData, 3000);

// Initial call to populate data
updateCourtData();
