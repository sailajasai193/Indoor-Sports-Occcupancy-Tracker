// Function to validate login form
function validateForm() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('error-message');

    // Basic validation
    if (username === "" || password === "") {
        errorMessage.textContent = "Username and password are required.";
        return false;
    }

    // Check if username and password match expected format
    // (For real-world applications, validate via backend API)
    if (username === "student" && password === "1234") {  // Dummy credentials
        alert("Login successful!");
        window.location.href = "index.html";  // Redirect to main page
        return true;
    } else {
        errorMessage.textContent = "Invalid username or password.";
        return false;
    }
}
